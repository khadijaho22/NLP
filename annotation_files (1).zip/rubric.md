# Rating rubric (content correctness ONLY)

Rate how well the candidate answer answers the question, compared with the reference answer.
IGNORE dialect, script (Arabic/Latin), spelling, grammar, and English words. Judge only the information.

5 = Fully correct and complete
4 = Correct, with a minor omission
3 = Partially correct (some key information missing, nothing false)
2 = Mostly wrong, with a trace of correct information
1 = Wrong or irrelevant

Do not try to guess which writing style is "better". Two answers with the same information must get the same rating.
